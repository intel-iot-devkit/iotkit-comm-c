#include <stdio.h>

int main() {
while(1) {
printf("hello world\n");
} 
return 0;
}
